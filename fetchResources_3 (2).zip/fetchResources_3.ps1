﻿
$sqlConn = New-Object System.Data.SqlClient.SqlConnection
$sqlConn.ConnectionString = “Server=tcp:rajoserver.database.windows.net,1433;Initial Catalog=rajodb;Persist Security Info=False;User ID=rajorshi;Password=Qwertyuiop@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;”
$sqlConn.Open()
$sqlcmd = $sqlConn.CreateCommand()
$sqlcmd.Connection = $sqlConn
while(1){
    $query = “SELECT TOP 1 ResourceGroupID,ResourceGroupName,InternalResourceDeploymentStatus from dbo.ResourceGroups ORDER BY ID DESC”
    $sqlcmd.CommandText = $query 
    $adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd
    $data = New-Object System.Data.DataSet 
    $adp.Fill($data) | Out-Null
    $resourceGroupName =$data.Tables[0].ResourceGroupName
    $resourceGroupId = $data.Tables[0].ResourceGroupID
    $resourceGroupDeploymentStatus = $data.Tables[0].InternalResourceDeploymentStatus
    $flag = 1
    $ResourceList = $null

    if( (-Not $resourceGroupName) -Or ($resourceGroupDeploymentStatus -eq 'Completed')){
        $resourceGroupName = "emptyresource"
    }

    while($resourceGroupDeploymentStatus -eq "Pending"){
        "Deployment is going on for "+$resourceGroupName
        $ResourceList = Get-AzureRmResourceGroupDeployment -ErrorAction SilentlyContinue -ResourceGroupName $resourceGroupName 
        if(-Not $ResourceList){
            $ResourceList = Get-AzureRmResourceGroupDeployment -ErrorAction SilentlyContinue -ResourceGroupName $resourceGroupName 
            "Waiting for deployment to start"
            Start-Sleep -Milliseconds 2000
        }ELSE{

            Foreach ($Resource in $ResourceList){
            "********************************"
                $indivudualResource = Find-AzureRmResource -ResourceNameContains $Resource.DeploymentName -ResourceGroupNameContains $resourceGroupName -ExpandProperties -ErrorAction Ignore
                if($Resource){
                "Individual Resource name"+$indivudualResource.Name
                "Deploying " +$Resource.DeploymentName+ " State - "+$Resource.ProvisioningState
                }
                if($indivudualResource){
                        $resourceId = $indivudualResource.ResourceId
                        $resourceName = $indivudualResource.ResourceName
                        $resourceType = $indivudualResource.ResourceType
                        $resourceLocation = $indivudualResource.Location
                        $resourceTags = $indivudualResource.Tags
                        $resourceSubscriptionId = $indivudualResource.SubscriptionId
                        $resourceResourceGroupName = $indivudualResource.ResourceGroupName
                        $resourceResourceGroupId = $resourceGroupId
                        $resourceProvisioningStatus= $Resource.ProvisioningState
                        $resourceDeploymentName = $Resource.DeploymentName
                        $resourceProperties = $indivudualResource.Properties

                #Store Individual resources
                        $foundId = $null
                        $foundName = $null
                        $query = “SELECT ResourceId,ResourceName from dbo.Resources where ResourceId = '$resourceId' and ResourceName='$resourceName'”
                        $sqlcmd.CommandText = $query 
                        $adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd
                        $data = New-Object System.Data.DataSet 
                        $adp.Fill($data) | Out-Null
                        $foundId =$data.Tables[0].ResourceId
                        $foundName =$data.Tables[0].ResourceName
                        $data.Tables[0]+"Found id "+$foundId
                        if((-Not $foundId) -and (-Not $foundName)){

                        $query = “SELECT id from dbo.ResourceGroups where ResourceGroupName = '$resourceResourceGroupName'”
                        $sqlcmd.CommandText = $query 
                        $adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd
                        $data = New-Object System.Data.DataSet 
                        $adp.Fill($data) | Out-Null
                        $groupId =$data.Tables[0].id


                 
                            $query = “INSERT INTO dbo.Resources(ResourceName,ResourceId,ResourceType,ResourceGroupName,ResourceGroupId,Location,SubscriptionId,Tags,ProvisioningState,ResourceDeploymentName,Properties) OUTPUT INSERTED.id VALUES ('$resourceName','$resourceId','$resourceType','$resourceResourceGroupName','$groupId','$resourceLocation','$resourceSubscriptionId','$resourceTags','$resourceProvisioningStatus','$resourceDeploymentName','$resourceProperties')”
                            $sqlcmd.CommandText = $query
                            $InsertedID = $sqlcmd.executenonquery()
                            "Inserting!!!!!!"+$InsertedID
                        
                        }


                        if(($foundId -eq $null) -and ($foundName -eq $null)){
                            $query = “UPDATE dbo.Resources set ProvisioningState='$resourceProvisioningStatus',Properties='$resourceProperties' where ResourceId='$resourceId'”
                            $sqlcmd.CommandText = $query 
                            $sqlcmd.executenonquery()
                            "Updated"
                        }
                        
                        if($resourceProvisioningStatus -eq "Failed" -Or $resourceProvisioningStatus -eq "Succeeded"){
                            $query = “UPDATE dbo.Resources set ProvisioningState='$resourceProvisioningStatus', Properties='$resourceProperties' where ResourceId='$resourceId'”
                            $sqlcmd.CommandText = $query 
                            $sqlcmd.executenonquery()
                            "Updated"


                            #Properties first fetching id from resource  table and storing properties with those id with a one-to-many relation
                            #adding properties
                                $query = “SELECT id from dbo.Resources where ResourceId = '$resourceId' and ResourceName='$resourceName' and ResourceGroupId !='0' ”
                                $sqlcmd.CommandText = $query 
                                $adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd
                                $data = New-Object System.Data.DataSet 
                                $adp.Fill($data) | Out-Null
                                $resourceNewId =$data.Tables[0].id

                                $query = “SELECT id from dbo.test where ResourceId = '$resourceNewId'”
                                $sqlcmd.CommandText = $query 
                                $adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd
                                $data = New-Object System.Data.DataSet 
                                $adp.Fill($data) | Out-Null
                                $resourcePropId =$data.Tables[0].id



                            if(-not $resourcePropId -and $resourceNewId){
                                    $resourceProperties.PSObject.Properties | ForEach-Object {  
                                    $name = $_.Name         
                                    $value = $_.Value                                                 
                                        $query = “INSERT INTO dbo.test VALUES ('$resourceNewId','$name','$value')”
                                        $sqlcmd.CommandText = $query
                                        $sqlcmd.executenonquery()
                                    }
                            }
                            
                            #

                        }

                # Store status to DB for the Resource Group




                }


                if( $ResourceList[-1].ProvisioningState -eq "Succeeded"){
                    $query = “UPDATE dbo.ResourceGroups set InternalResourceDeploymentStatus='Completed' where ResourceGroupName='$resourceGroupName '”
                    $sqlcmd.CommandText = $query 
                    $sqlcmd.executenonquery()
                    $resourceGroupName = "emptyresource"
                    $resourceGroupDeploymentStatus = "Completed"
                    "Completed"
                    $flag=0
                    $insertedResources = $null
                    break;
                }
                if( $ResourceList[-1].ProvisioningState -eq "Failed"){
                    $newResourceGroupName = $resourceGroupName+"(F)"
                    $failedResource = $Resource.DeploymentName
                    $query = “UPDATE dbo.ResourceGroups set FailedDueTo='$failedResource',ResourceGroupName='$newResourceGroupName',InternalResourceDeploymentStatus='Failed' where ResourceGroupID='$resourceGroupId'”
                    $sqlcmd.CommandText = $query 
                    $sqlcmd.executenonquery()
                    $resourceGroupName = "emptyresource"
                    $resourceGroupDeploymentStatus = "Failed"
                    "Failed"
                     $flag=0
                     $insertedResources=$null
                    break;
                }

            }
    
        }


        
        #$ResourceList = Find-AzureRmResource -ResourceGroupName $resourceGroupName -ExpandProperties 
        #$state = $lastRgDeployment[0].ProvisioningState
        #$location =$lastRgDeployment[0].Location
        #$tags = $lastRgDeployment[0].Tags
        #$id = $lastRgDeployment[0].ResourceId
        Start-Sleep -Milliseconds 2000
        if($flag -eq 0){
                $ResourceList=$null
                 $flag=1
                break;
            }
    }



        "No resources to deploy"
        
    $ResourceList=$null


    
        if($flag -eq 1){
                Start-Sleep -Milliseconds 3000
            }
}




$sqlConn.Close()