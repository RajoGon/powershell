﻿# Clean ResourceGroup Deployments table for deleted Resource Groups
$resourceGroupName=$null
$sqlConn = New-Object System.Data.SqlClient.SqlConnection
$sqlConn.ConnectionString = “Server=tcp:rajoserver.database.windows.net,1433;Initial Catalog=rajodb;Persist Security Info=False;User ID=rajorshi;Password=Qwertyuiop@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;”
$sqlConn.Open()
$sqlcmd = $sqlConn.CreateCommand()
$sqlcmd.Connection = $sqlConn
while(1){
    

    $query = “SELECT ResourceGroupName,DeploymentStatus from dbo.ResourceGroups ORDER BY ID DESC”
    $sqlcmd.CommandText = $query 
    $adp = New-Object System.Data.SqlClient.SqlDataAdapter $sqlcmd
    $data = New-Object System.Data.DataSet 
    $adp.Fill($data) | Out-Null
    
    Foreach ($ResourceData in $data.Tables[0]){
    $resourceGroupName =$ResourceData.ResourceGroupName
    $resourceGroupStatus = $ResourceData.DeploymentStatus
    #$resourceGroupName+" sadasdad"+$resourceGroupStatus 
            if(-Not $resourceGroupName){
                    "No resource groups in database"
            }
            ELSE{
                if($resourceGroupStatus -eq "Deleted"){
                }
                ELSE{
                    Foreach ($Resource in $resourceGroupName){
                        $searchedResource = Get-AzureRmResourceGroup -ErrorAction SilentlyContinue -Name $Resource
                        if(-Not $searchedResource){
                        $newDeletedResourceGroupName = $Resource+'(Deleted)'
                            "Deleting Resource group :- "+ $Resource
                            #
                            $query = “UPDATE dbo.Resources set ResourceId='N/A(Deleted)',ResourceGroupName='$newDeletedResourceGroupName'  where ResourceGroupName='$Resource'”
                            $sqlcmd.CommandText = $query
                            $sqlcmd.executenonquery()

                            $query = “DELETE from dbo.Resources where ResourceGroupId=0”
                            $sqlcmd.CommandText = $query 
                            $sqlcmd.executescalar()

                            $query = “DELETE from dbo.test where ResourceId=0”
                            $sqlcmd.CommandText = $query 
                            $sqlcmd.executescalar()
                            #


                            $newDeletedResourceGroupName = $Resource+'(Deleted)'
                            $query = “UPDATE dbo.ResourceGroups set InternalResourceDeploymentStatus='Completed',DeploymentStatus='Deleted', ResourceGroupName='$newDeletedResourceGroupName' where ResourceGroupName='$Resource'”
                            $sqlcmd.CommandText = $query 
                            "Deleted "+$sqlcmd.executenonquery()+ " record(s)."


                            
                        }
                        ELSE{
                            "Found no resource group to delete from the database."
                        }
                    }
                }


            }
     }
    Start-Sleep -Milliseconds 3000
}
$sqlConn.Close()